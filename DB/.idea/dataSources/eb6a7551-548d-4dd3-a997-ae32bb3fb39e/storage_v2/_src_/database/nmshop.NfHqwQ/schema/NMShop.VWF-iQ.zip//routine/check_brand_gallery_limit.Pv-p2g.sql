create function check_brand_gallery_limit() returns trigger
    language plpgsql
as
$$
DECLARE
    brand_gallery_count integer;
BEGIN
    SELECT COUNT(*) INTO brand_gallery_count FROM "BrandGalleryItems" WHERE "Brand_Id" = NEW."Brand_Id";
    IF brand_gallery_count >= 3 THEN
        RAISE EXCEPTION 'Нельзя добавить больше 3 записей в галерею брендов.';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_brand_gallery_limit() owner to m0rp3x;

