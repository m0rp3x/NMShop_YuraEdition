create function check_promo_code_validity() returns trigger
    language plpgsql
as
$$
DECLARE
    promo_usage_count integer;
BEGIN
    IF NEW."PromoCode_Id" IS NOT NULL THEN
        -- Указываем схему NMShop явно при обращении к таблице Orders
        SELECT COUNT(*) INTO promo_usage_count
        FROM "Orders"
        WHERE "PromoCode_Id" = NEW."PromoCode_Id";

        -- Проверяем максимальное количество использований
        IF promo_usage_count >= (SELECT "MaxUsages" FROM "NMShop"."PromoCodes" WHERE "Id" = NEW."PromoCode_Id") THEN
            RAISE EXCEPTION 'Промокод достиг максимального количества использований.';
        END IF;

        -- Проверяем срок действия промокода
        IF (SELECT "ExpirationDate" FROM "NMShop"."PromoCodes" WHERE "Id" = NEW."PromoCode_Id") < CURRENT_DATE THEN
            RAISE EXCEPTION 'Срок действия промокода истек.';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

alter function check_promo_code_validity() owner to postgres;

