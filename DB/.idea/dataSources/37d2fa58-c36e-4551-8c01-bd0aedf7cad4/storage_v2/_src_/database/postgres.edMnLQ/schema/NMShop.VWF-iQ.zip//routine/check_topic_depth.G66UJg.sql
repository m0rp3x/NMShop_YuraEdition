create function check_topic_depth() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW."ParentTopic_Id" IS NOT NULL THEN
        IF EXISTS (
            SELECT 1 FROM "ReferenceTopics"
            WHERE "Id" = NEW."ParentTopic_Id" AND "ParentTopic_Id" IS NOT NULL
        ) THEN
            RAISE EXCEPTION 'Топик справочной информации не должен иметь собственного родителя.';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

alter function check_topic_depth() owner to postgres;

