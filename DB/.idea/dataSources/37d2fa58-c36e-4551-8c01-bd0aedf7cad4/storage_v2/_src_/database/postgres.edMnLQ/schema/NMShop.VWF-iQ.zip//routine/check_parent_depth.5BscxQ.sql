create function check_parent_depth() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW."ParentType_Id" IS NOT NULL THEN
        -- Проверяем, что у родительского типа нет собственного родителя
        IF EXISTS (
            SELECT 1 FROM "ProductTypes"
            WHERE "Id" = NEW."ParentType_Id" AND "ParentType_Id" IS NOT NULL
        ) THEN
            RAISE EXCEPTION 'Родительский тип не должен иметь собственного родителя.';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

alter function check_parent_depth() owner to postgres;

