create function check_navigation_depth() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW."ParentItem_Id" IS NOT NULL THEN
        IF EXISTS (
            SELECT 1 FROM "NavigationItems"
            WHERE "Id" = NEW."ParentItem_Id" AND "ParentItem_Id" IS NOT NULL
        ) THEN
            RAISE EXCEPTION 'Навигационный пункт не должен иметь собственного родителя.';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

alter function check_navigation_depth() owner to postgres;

